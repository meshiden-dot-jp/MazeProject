using UnityEngine;

public class CameraController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public Transform MoveTerget;
    public Transform LookTarget;
    public Vector3 PositionOffset;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
